﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemas_de_ecuaciones
{
    public partial class Menu_Mate : Form
    {
        public Menu_Mate()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PARABOLA ventana = new PARABOLA();
            ventana.Show();

            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RECTA  ventana = new RECTA();
            ventana.Show();

            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CIRCUFERENCIA ventana = new CIRCUFERENCIA();
            ventana.Show();

            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ELIPSE ventana = new ELIPSE();
            ventana.Show();

            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            HIPERBOLA ventana = new HIPERBOLA();
            ventana.Show();

            this.Hide();
        }

        private void Menu_Mate_Load(object sender, EventArgs e)
        {
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderSize = 0;

            button2.FlatStyle = FlatStyle.Flat;
            button2.FlatAppearance.BorderSize = 0;

            button3.FlatStyle = FlatStyle.Flat;
            button3.FlatAppearance.BorderSize = 0;

            button4.FlatStyle = FlatStyle.Flat;
            button4.FlatAppearance.BorderSize = 0;

            button5.FlatStyle = FlatStyle.Flat;
            button5.FlatAppearance.BorderSize = 0;
        }
        

        

        

        private void button10_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MENU MENU = new MENU();
            MENU.Show();
            this.Hide();
        }
    }
}
