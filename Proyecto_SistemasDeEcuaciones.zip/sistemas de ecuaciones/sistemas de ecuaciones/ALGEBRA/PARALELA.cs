﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace sistemas_de_ecuaciones.ALGEBRA
{
    public partial class PARALELA : Form
    {
        public PARALELA()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            // Obtener los valores de los TextBoxes
            double x = double.Parse(txtPuntoX.Text);
            double y = double.Parse(txtPuntoY.Text);
            double a = double.Parse(txtCoeficienteA.Text);
            double b = double.Parse(txtCoeficienteB.Text);
            double c = double.Parse(txtCoeficienteC.Text);

            // Calcular la pendiente de la recta dada
            double pendiente = -a / b;

            // Calcular el término de intersección (b) de la recta dada
            double terminoInterseccion = -c / b;

            // Calcular el término de intersección (b) de la recta paralela
            double terminoInterseccionParalela = y - pendiente * x;

            // Construir la ecuación de la recta paralela
            string ecuacionParalela = $"y = {pendiente}x + {terminoInterseccionParalela}";

            // Mostrar el procedimiento y el resultado en el Label
            string resultadoFinal = $"Procedimiento:\nPendiente de la recta dada: {pendiente}\nTérmino de intersección de la recta dada: {terminoInterseccion}\nTérmino de intersección de la recta paralela: {terminoInterseccionParalela}\n\nResultado:\n{ecuacionParalela}";
            lblResultado.Text = resultadoFinal;

            // Limpiar el Chart
            chart1.Series.Clear();

            // Configurar el intervalo y rango del Chart
            chart1.ChartAreas[0].AxisX.Minimum = -10;
            chart1.ChartAreas[0].AxisX.Maximum = 10;
            chart1.ChartAreas[0].AxisY.Minimum = -10;
            chart1.ChartAreas[0].AxisY.Maximum = 10;

            // Agregar la serie para la recta dada
            Series serieRectaDada = chart1.Series.Add("Recta Dada");
            serieRectaDada.ChartType = SeriesChartType.Line;
            serieRectaDada.Points.AddXY(-10, (-a / b) * -10 + (-c / b));
            serieRectaDada.Points.AddXY(10, (-a / b) * 10 + (-c / b));

            // Agregar la serie para la recta paralela
            Series serieRectaParalela = chart1.Series.Add("Recta Paralela");
            serieRectaParalela.ChartType = SeriesChartType.Line;
            serieRectaParalela.Points.AddXY(-10, pendiente * -10 + terminoInterseccionParalela);
            serieRectaParalela.Points.AddXY(10, pendiente * 10 + terminoInterseccionParalela);

            // Configurar los ejes x e y
            chart1.ChartAreas[0].AxisX.Minimum = -10;
            chart1.ChartAreas[0].AxisX.Maximum = 10;
            
            chart1.ChartAreas[0].AxisY.Minimum = -10;
            chart1.ChartAreas[0].AxisY.Maximum = 10;
            chart1.ChartAreas[0].AxisX.Interval = .25;
            chart1.ChartAreas[0].AxisY.Interval = .25;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            GRAFICA GRAFICA = new GRAFICA();
            GRAFICA.Show();
            this.Hide();
        }

        private void PARALELA_Load(object sender, EventArgs e)
        {

        }
    }
}
