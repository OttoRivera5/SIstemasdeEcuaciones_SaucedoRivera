﻿namespace sistemas_de_ecuaciones
{
    partial class ELIMINACION
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblResul = new System.Windows.Forms.Label();
            this.lblResulQ3 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblResulQ2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblResulq1 = new System.Windows.Forms.Label();
            this.lblTituloValores = new System.Windows.Forms.Label();
            this.lblTituloProc = new System.Windows.Forms.Label();
            this.lblXX = new System.Windows.Forms.Label();
            this.lblX = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblMostrarSoluY = new System.Windows.Forms.Label();
            this.lblMostrarSoluc = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txta2 = new System.Windows.Forms.TextBox();
            this.txtb2 = new System.Windows.Forms.TextBox();
            this.txtc2 = new System.Windows.Forms.TextBox();
            this.txtb1 = new System.Windows.Forms.TextBox();
            this.txtc1 = new System.Windows.Forms.TextBox();
            this.txta1 = new System.Windows.Forms.TextBox();
            this.btnResolver = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(260, 219);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 20);
            this.label12.TabIndex = 113;
            this.label12.Text = "22";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(222, 190);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(27, 20);
            this.label10.TabIndex = 112;
            this.label10.Text = "11";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(185, 153);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 20);
            this.label8.TabIndex = 111;
            this.label8.Text = "Calcular Factor";
            this.label8.Visible = false;
            // 
            // lblResul
            // 
            this.lblResul.AutoSize = true;
            this.lblResul.BackColor = System.Drawing.Color.Transparent;
            this.lblResul.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResul.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblResul.Location = new System.Drawing.Point(410, 263);
            this.lblResul.Name = "lblResul";
            this.lblResul.Size = new System.Drawing.Size(18, 20);
            this.lblResul.TabIndex = 110;
            this.lblResul.Text = "7";
            // 
            // lblResulQ3
            // 
            this.lblResulQ3.AutoSize = true;
            this.lblResulQ3.BackColor = System.Drawing.Color.Transparent;
            this.lblResulQ3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResulQ3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblResulQ3.Location = new System.Drawing.Point(614, 222);
            this.lblResulQ3.Name = "lblResulQ3";
            this.lblResulQ3.Size = new System.Drawing.Size(18, 20);
            this.lblResulQ3.TabIndex = 109;
            this.lblResulQ3.Text = "6";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(593, 193);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 20);
            this.label13.TabIndex = 108;
            this.label13.Text = "3";
            // 
            // lblResulQ2
            // 
            this.lblResulQ2.AutoSize = true;
            this.lblResulQ2.BackColor = System.Drawing.Color.Transparent;
            this.lblResulQ2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResulQ2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblResulQ2.Location = new System.Drawing.Point(502, 222);
            this.lblResulQ2.Name = "lblResulQ2";
            this.lblResulQ2.Size = new System.Drawing.Size(18, 20);
            this.lblResulQ2.TabIndex = 107;
            this.lblResulQ2.Text = "5";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(481, 193);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 20);
            this.label11.TabIndex = 106;
            this.label11.Text = "2";
            // 
            // lblResulq1
            // 
            this.lblResulq1.AutoSize = true;
            this.lblResulq1.BackColor = System.Drawing.Color.Transparent;
            this.lblResulq1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResulq1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblResulq1.Location = new System.Drawing.Point(398, 222);
            this.lblResulq1.Name = "lblResulq1";
            this.lblResulq1.Size = new System.Drawing.Size(18, 20);
            this.lblResulq1.TabIndex = 105;
            this.lblResulq1.Text = "4";
            // 
            // lblTituloValores
            // 
            this.lblTituloValores.AutoSize = true;
            this.lblTituloValores.BackColor = System.Drawing.Color.Transparent;
            this.lblTituloValores.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloValores.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTituloValores.Location = new System.Drawing.Point(260, 305);
            this.lblTituloValores.Name = "lblTituloValores";
            this.lblTituloValores.Size = new System.Drawing.Size(154, 20);
            this.lblTituloValores.TabIndex = 104;
            this.lblTituloValores.Text = "Calcular Valores X Y";
            this.lblTituloValores.Visible = false;
            // 
            // lblTituloProc
            // 
            this.lblTituloProc.AutoSize = true;
            this.lblTituloProc.BackColor = System.Drawing.Color.Transparent;
            this.lblTituloProc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloProc.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTituloProc.Location = new System.Drawing.Point(345, 153);
            this.lblTituloProc.Name = "lblTituloProc";
            this.lblTituloProc.Size = new System.Drawing.Size(165, 20);
            this.lblTituloProc.TabIndex = 103;
            this.lblTituloProc.Text = "Realizar la eliminación";
            this.lblTituloProc.Visible = false;
            // 
            // lblXX
            // 
            this.lblXX.AutoSize = true;
            this.lblXX.BackColor = System.Drawing.Color.Transparent;
            this.lblXX.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXX.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblXX.Location = new System.Drawing.Point(339, 340);
            this.lblXX.Name = "lblXX";
            this.lblXX.Size = new System.Drawing.Size(36, 20);
            this.lblXX.TabIndex = 102;
            this.lblXX.Text = "111";
            this.lblXX.Visible = false;
            // 
            // lblX
            // 
            this.lblX.AutoSize = true;
            this.lblX.BackColor = System.Drawing.Color.Transparent;
            this.lblX.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblX.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblX.Location = new System.Drawing.Point(377, 193);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(18, 20);
            this.lblX.TabIndex = 101;
            this.lblX.Text = "1";
            this.lblX.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(259, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(268, 26);
            this.label6.TabIndex = 100;
            this.label6.Text = "Pasos De Procedimientos";
            this.label6.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(478, 459);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 31);
            this.label9.TabIndex = 98;
            this.label9.Text = "y";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(478, 403);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 31);
            this.label7.TabIndex = 97;
            this.label7.Text = "x";
            // 
            // lblMostrarSoluY
            // 
            this.lblMostrarSoluY.AutoSize = true;
            this.lblMostrarSoluY.BackColor = System.Drawing.Color.Transparent;
            this.lblMostrarSoluY.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarSoluY.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblMostrarSoluY.Location = new System.Drawing.Point(258, 459);
            this.lblMostrarSoluY.Name = "lblMostrarSoluY";
            this.lblMostrarSoluY.Size = new System.Drawing.Size(187, 31);
            this.lblMostrarSoluY.TabIndex = 96;
            this.lblMostrarSoluY.Text = "solucion de y: ";
            this.lblMostrarSoluY.Visible = false;
            // 
            // lblMostrarSoluc
            // 
            this.lblMostrarSoluc.AutoSize = true;
            this.lblMostrarSoluc.BackColor = System.Drawing.Color.Transparent;
            this.lblMostrarSoluc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarSoluc.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblMostrarSoluc.Location = new System.Drawing.Point(258, 403);
            this.lblMostrarSoluc.Name = "lblMostrarSoluc";
            this.lblMostrarSoluc.Size = new System.Drawing.Size(186, 31);
            this.lblMostrarSoluc.TabIndex = 95;
            this.lblMostrarSoluc.Text = "solucion de x: ";
            this.lblMostrarSoluc.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(80, 111);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 20);
            this.label5.TabIndex = 94;
            this.label5.Text = "+";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(80, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 20);
            this.label4.TabIndex = 93;
            this.label4.Text = "+";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(147, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 20);
            this.label3.TabIndex = 92;
            this.label3.Text = "=";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(147, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 20);
            this.label2.TabIndex = 91;
            this.label2.Text = "=";
            // 
            // txta2
            // 
            this.txta2.Location = new System.Drawing.Point(33, 110);
            this.txta2.Name = "txta2";
            this.txta2.Size = new System.Drawing.Size(38, 20);
            this.txta2.TabIndex = 90;
            // 
            // txtb2
            // 
            this.txtb2.Location = new System.Drawing.Point(104, 110);
            this.txtb2.Name = "txtb2";
            this.txtb2.Size = new System.Drawing.Size(37, 20);
            this.txtb2.TabIndex = 89;
            // 
            // txtc2
            // 
            this.txtc2.Location = new System.Drawing.Point(171, 112);
            this.txtc2.Name = "txtc2";
            this.txtc2.Size = new System.Drawing.Size(31, 20);
            this.txtc2.TabIndex = 88;
            // 
            // txtb1
            // 
            this.txtb1.Location = new System.Drawing.Point(104, 62);
            this.txtb1.Name = "txtb1";
            this.txtb1.Size = new System.Drawing.Size(37, 20);
            this.txtb1.TabIndex = 87;
            // 
            // txtc1
            // 
            this.txtc1.Location = new System.Drawing.Point(171, 62);
            this.txtc1.Name = "txtc1";
            this.txtc1.Size = new System.Drawing.Size(31, 20);
            this.txtc1.TabIndex = 86;
            // 
            // txta1
            // 
            this.txta1.Location = new System.Drawing.Point(33, 62);
            this.txta1.Name = "txta1";
            this.txta1.Size = new System.Drawing.Size(38, 20);
            this.txta1.TabIndex = 85;
            // 
            // btnResolver
            // 
            this.btnResolver.Location = new System.Drawing.Point(84, 282);
            this.btnResolver.Name = "btnResolver";
            this.btnResolver.Size = new System.Drawing.Size(75, 23);
            this.btnResolver.TabIndex = 114;
            this.btnResolver.Text = "RESOLVER";
            this.btnResolver.UseVisualStyleBackColor = true;
            this.btnResolver.Click += new System.EventHandler(this.btnResolver_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(84, 358);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 115;
            this.btnLimpiar.Text = "LIMPIAR";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.BackgroundImage = global::sistemas_de_ecuaciones.Properties.Resources.flecha_hacia_atras;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(564, 15);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(40, 43);
            this.button6.TabIndex = 142;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImage = global::sistemas_de_ecuaciones.Properties.Resources.comprimir__1_;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(678, 12);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(44, 46);
            this.button4.TabIndex = 141;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.BackgroundImage = global::sistemas_de_ecuaciones.Properties.Resources.cerrar_sesion__2_;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(620, 12);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(44, 44);
            this.button5.TabIndex = 140;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // ELIMINACION
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::sistemas_de_ecuaciones.Properties.Resources._156415_negro_color_gris_triangulo_simetria_1920x1080;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(734, 521);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnResolver);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblResul);
            this.Controls.Add(this.lblResulQ3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblResulQ2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblResulq1);
            this.Controls.Add(this.lblTituloValores);
            this.Controls.Add(this.lblTituloProc);
            this.Controls.Add(this.lblXX);
            this.Controls.Add(this.lblX);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblMostrarSoluY);
            this.Controls.Add(this.lblMostrarSoluc);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txta2);
            this.Controls.Add(this.txtb2);
            this.Controls.Add(this.txtc2);
            this.Controls.Add(this.txtb1);
            this.Controls.Add(this.txtc1);
            this.Controls.Add(this.txta1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ELIMINACION";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ELIMINACION";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblResul;
        private System.Windows.Forms.Label lblResulQ3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblResulQ2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblResulq1;
        private System.Windows.Forms.Label lblTituloValores;
        private System.Windows.Forms.Label lblTituloProc;
        private System.Windows.Forms.Label lblXX;
        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblMostrarSoluY;
        private System.Windows.Forms.Label lblMostrarSoluc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txta2;
        private System.Windows.Forms.TextBox txtb2;
        private System.Windows.Forms.TextBox txtc2;
        private System.Windows.Forms.TextBox txtb1;
        private System.Windows.Forms.TextBox txtc1;
        private System.Windows.Forms.TextBox txta1;
        private System.Windows.Forms.Button btnResolver;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
    }
}