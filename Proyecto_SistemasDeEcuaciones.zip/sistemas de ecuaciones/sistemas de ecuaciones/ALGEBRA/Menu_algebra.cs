﻿using sistemas_de_ecuaciones.ALGEBRA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemas_de_ecuaciones
{
    public partial class Menu_algebra : Form
    {
        public Menu_algebra()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ELIMINACION ventana = new ELIMINACION();
            ventana.Show();

            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            IGUALACION ventana = new IGUALACION();
            ventana.Show();

            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
           SUSTITUCION ventana = new SUSTITUCION();
            ventana.Show();

            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DETERMINANTES ventana = new DETERMINANTES();
            ventana.Show();

            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            VECTORES ventana = new VECTORES();
            ventana.Show();

            this.Hide();
        }

        private void Menu_algebra_Load(object sender, EventArgs e)
        {
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderSize = 0;

            button2.FlatStyle = FlatStyle.Flat;
            button2.FlatAppearance.BorderSize = 0;

            button3.FlatStyle = FlatStyle.Flat;
            button3.FlatAppearance.BorderSize = 0;

            button4.FlatStyle = FlatStyle.Flat;
            button4.FlatAppearance.BorderSize = 0;

            button5.FlatStyle = FlatStyle.Flat;
            button5.FlatAppearance.BorderSize = 0;

            button6.FlatStyle = FlatStyle.Flat;
            button6.FlatAppearance.BorderSize = 0;

            button7.FlatStyle = FlatStyle.Flat;
            button7.FlatAppearance.BorderSize = 0;

            button8.FlatStyle = FlatStyle.Flat;
            button8.FlatAppearance.BorderSize = 0;

            button9.FlatStyle = FlatStyle.Flat;
            button9.FlatAppearance.BorderSize = 0;

            button10.FlatStyle = FlatStyle.Flat;
            button10.FlatAppearance.BorderSize = 0;
        }

        

        private void button9_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MENU MENU = new MENU();
            MENU.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MATRICES ventana = new MATRICES();
            ventana.Show();

            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            GRAFICA ventana = new GRAFICA();
            ventana.Show();

            this.Hide();
        }
    }
}
