﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace sistemas_de_ecuaciones.ALGEBRA
{
    public partial class PERPENDICULAR : Form
    {
        public PERPENDICULAR()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener la ecuación y=ax+b ingresada en el TextBox
                string ecuacionOriginal = txtEcuacion.Text;

                // Eliminar los espacios en blanco de la ecuación
                ecuacionOriginal = ecuacionOriginal.Replace(" ", "");

                // Verificar si la ecuación tiene el formato correcto
                if (ecuacionOriginal.StartsWith("y="))
                {
                    // Extraer los coeficientes a y b de la ecuación original
                    int indexA = ecuacionOriginal.IndexOf("x");
                    double a = double.Parse(ecuacionOriginal.Substring(2, indexA - 2));
                    double b = double.Parse(ecuacionOriginal.Substring(indexA + 1));

                    // Obtener los valores de los puntos x e y ingresados en los TextBox
                    double puntoX = double.Parse(txtPuntoX.Text);
                    double puntoY = double.Parse(txtPuntoY.Text);

                    // Calcular la pendiente de la recta original y la pendiente de la recta perpendicular
                    double pendienteOriginal = a;
                    double pendientePerpendicular = -1 / pendienteOriginal;

                    // Calcular el término independiente b de la ecuación perpendicular
                    double bPerpendicular = puntoY - pendientePerpendicular * puntoX;

                    // Construir la ecuación de la recta perpendicular
                    string ecuacionPerpendicular = $"y = {pendientePerpendicular}x + {bPerpendicular}";

                    // Mostrar el procedimiento y resultado en el Label
                    lblResultado.Text = $"Procedimiento:\n\nLa ecuación original es {ecuacionOriginal}.\nLa pendiente de la recta original es {pendienteOriginal}.\n\nLa pendiente de la recta perpendicular es {pendientePerpendicular}.\nEl término independiente de la recta perpendicular es {bPerpendicular}.\n\nLa ecuación de la recta perpendicular es:\n{ecuacionPerpendicular}.";

                    // Limpiar la gráfica
                    chart.Series.Clear();

                    // Crear la serie para la recta original
                    Series serieOriginal = new Series();
                    serieOriginal.ChartType = SeriesChartType.Line;
                    serieOriginal.Color = System.Drawing.Color.Blue;

                    // Agregar puntos a la serie original para dibujar la recta
                    serieOriginal.Points.AddXY(-10, a * -10 + b);
                    serieOriginal.Points.AddXY(10, a * 10 + b);

                    // Agregar la serie original a la gráfica
                    chart.Series.Add(serieOriginal);

                    // Crear la serie para la recta perpendicular
                    Series seriePerpendicular = new Series();
                    seriePerpendicular.ChartType = SeriesChartType.Line;
                    seriePerpendicular.Color = System.Drawing.Color.Red;

                    // Calcular los puntos para la recta perpendicular
                    double minY = a * -10 + b;
                    double maxY = a * 10 + b;
                    double minX = (minY - bPerpendicular) / pendientePerpendicular;
                    double maxX = (maxY - bPerpendicular) / pendientePerpendicular;

                    // Agregar puntos a la serie perpendicular para dibujar la recta
                    seriePerpendicular.Points.AddXY(minX, minY);
                    seriePerpendicular.Points.AddXY(maxX, maxY);

                    // Agregar la serie perpendicular a la gráfica
                    chart.Series.Add(seriePerpendicular);

                    // Configurar los ejes x e y
                    chart.ChartAreas[0].AxisX.Minimum = -10;
                    chart.ChartAreas[0].AxisX.Maximum = 10;
                        
                    chart.ChartAreas[0].AxisY.Minimum = -10;
                    chart.ChartAreas[0].AxisY.Maximum = 10;
                    chart.ChartAreas[0].AxisX.Interval = .25;
                    chart.ChartAreas[0].AxisY.Interval = .25;
                }
                else
                {
                    lblResultado.Text = "Error: Ingresa la ecuación en el formato y=ax+b.";
                }
            }
            catch (FormatException)
            {
                lblResultado.Text = "Error: Ingresa valores numéricos válidos para los puntos x e y y asegúrate de que la ecuación tenga el formato adecuado (y=ax+b).";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            GRAFICA GRAFICA = new GRAFICA();
            GRAFICA.Show();
            this.Hide();
        }
    }
}
